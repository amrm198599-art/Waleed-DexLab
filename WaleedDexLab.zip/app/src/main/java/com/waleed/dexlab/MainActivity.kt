package com.waleed.dexlab

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.core.content.FileProvider
import androidx.core.os.LocaleListCompat
import java.io.File

private val BG = Color(0xFF0B1020)
private val PURPLE = Color(0xFF7C4DFF)
private val CYAN = Color(0xFF00E5FF)

class MainActivity : AppCompatActivity() {
    private val vm: DexVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handle(intent)
        setContent { DexTheme { App(vm) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        if (i?.action == Intent.ACTION_VIEW) i.data?.let { vm.openUri(it) }
    }
}

@Composable
fun DexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = PURPLE, secondary = CYAN, background = BG, surface = Color(0xFF141A33),
            onBackground = Color.White, onSurface = Color.White
        ),
        content = { Surface(color = BG, modifier = Modifier.fillMaxSize(), content = content) }
    )
}

sealed interface Screen {
    object Home : Screen
    object Browser : Screen
    object Search : Screen
    object Settings : Screen
    data class Editor(val file: File) : Screen
}

@Composable
fun App(vm: DexVM) {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    LaunchedEffect(vm.project) { screen = if (vm.project != null) Screen.Browser else Screen.Home }

    BackHandler(enabled = screen != Screen.Home) {
        screen = when (val s = screen) {
            is Screen.Editor, Screen.Search -> Screen.Browser
            Screen.Browser -> {
                val r = vm.project; val c = vm.cwd
                if (r != null && c != null && c != r) { vm.cwd = c.parentFile; Screen.Browser }
                else { vm.close(); Screen.Home }
            }
            else -> Screen.Home
        }
    }

    when (val s = screen) {
        Screen.Home -> Home(vm) { screen = Screen.Settings }
        Screen.Settings -> SettingsScreen()
        Screen.Browser -> Browser(vm, onOpen = { screen = Screen.Editor(it) }, onSearch = { screen = Screen.Search })
        Screen.Search -> SearchScreen(vm) { screen = Screen.Editor(it) }
        is Screen.Editor -> EditorScreen(vm, s.file)
    }
}

@Composable
fun StatusBar(vm: DexVM) {
    Column(Modifier.fillMaxWidth()) {
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = CYAN)
        if (vm.status.isNotEmpty()) Text(vm.status, fontSize = 12.sp, color = Color(0xFFB8C0E0), modifier = Modifier.padding(vertical = 4.dp))
    }
}

@Composable
fun Home(vm: DexVM, onSettings: () -> Unit) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.openUri(u) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { vm.loadApps() }
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF241570), BG)))
            .statusBarsPadding().navigationBarsPadding().padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Android, null, tint = CYAN, modifier = Modifier.size(34.dp))
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.app_name), fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, stringResource(R.string.settings)) }
        }
        Text(stringResource(R.string.tagline), color = Color(0xFFB8C0E0), modifier = Modifier.padding(vertical = 8.dp))
        Button(
            onClick = { pick.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream", "*/*")) },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.open_apk))
        }
        StatusBar(vm)
        Text(stringResource(R.string.installed), fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp))
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            placeholder = { Text(stringResource(R.string.search_apps)) },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
        LazyColumn(Modifier.weight(1f)) {
            items(vm.apps.filter { it.label.contains(q, true) || it.pkg.contains(q, true) }) { a ->
                ListItem(
                    headlineContent = { Text(a.label) },
                    supportingContent = { Text(a.pkg, fontSize = 11.sp) },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    modifier = Modifier.clickable { vm.openInstalled(a) }
                )
            }
        }
    }
}

@Composable
fun Browser(vm: DexVM, onOpen: (File) -> Unit, onSearch: () -> Unit) {
    val root = vm.project ?: return
    val cwd = vm.cwd ?: root
    val ctx = LocalContext.current
    val export = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { u -> if (u != null) vm.export(u) }
    val children = remember(cwd, vm.busy) {
        (cwd.listFiles()?.toList() ?: emptyList()).sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("/" + cwd.relativeTo(root).path, fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = onSearch) { Icon(Icons.Default.Search, stringResource(R.string.search)) }
            IconButton(onClick = { vm.decompile() }, enabled = !vm.busy) { Icon(Icons.Default.Code, stringResource(R.string.decompile)) }
            IconButton(onClick = { vm.build() }, enabled = !vm.busy) { Icon(Icons.Default.Build, stringResource(R.string.build)) }
        }
        vm.signed?.let { f ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 6.dp)) {
                Button(onClick = { install(ctx, f) }) { Icon(Icons.Default.InstallMobile, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.install)) }
                OutlinedButton(onClick = { export.launch("signed.apk") }) { Icon(Icons.Default.SaveAlt, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.export_apk)) }
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(children) { f ->
                ListItem(
                    leadingContent = { Icon(if (f.isDirectory) Icons.Default.Folder else Icons.Default.Description, null, tint = if (f.isDirectory) CYAN else Color.White) },
                    headlineContent = { Text(f.name) },
                    supportingContent = {
                        Text(if (f.isDirectory) stringResource(R.string.folder_items, f.list()?.size ?: 0) else "${f.length() / 1024} KB", fontSize = 11.sp)
                    },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    modifier = Modifier.clickable { if (f.isDirectory) vm.cwd = f else onOpen(f) }
                )
            }
        }
        StatusBar(vm)
    }
}

@Composable
fun SearchScreen(vm: DexVM, onOpen: (File) -> Unit) {
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(12.dp)) {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            placeholder = { Text(stringResource(R.string.search_hint)) },
            trailingIcon = { IconButton(onClick = { vm.search(q) }) { Icon(Icons.Default.Search, null) } },
            modifier = Modifier.fillMaxWidth()
        )
        StatusBar(vm)
        if (vm.hits.isEmpty() && !vm.busy) Text(stringResource(R.string.no_results), color = Color.Gray, modifier = Modifier.padding(8.dp))
        LazyColumn {
            items(vm.hits) { h ->
                ListItem(
                    headlineContent = { Text(h.text, fontFamily = FontFamily.Monospace, fontSize = 12.sp, maxLines = 2) },
                    supportingContent = { Text("${h.rel}:${h.line}", fontSize = 11.sp, color = CYAN) },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    modifier = Modifier.clickable { onOpen(h.file) }
                )
            }
        }
    }
}

class Highlight : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        if (s.length > 150_000) return TransformedText(text, OffsetMapping.Identity)
        val a = AnnotatedString.Builder(s)
        fun paint(r: Regex, c: Color) = r.findAll(s).forEach { a.addStyle(SpanStyle(color = c), it.range.first, it.range.last + 1) }
        paint(Regex("\\b(invoke-[\\w/]+|const[\\w/-]*|move[\\w/-]*|return[\\w-]*|if-\\w+|goto|new-\\w+|[is](get|put)[\\w-]*)\\b"), Color(0xFF82AAFF))
        paint(Regex("\\b[vp]\\d+\\b"), Color(0xFFC792EA))
        paint(Regex("^\\s*\\.[a-z-]+", RegexOption.MULTILINE), Color(0xFFFFCB6B))
        paint(Regex("</?[\\w:.-]+"), Color(0xFFFFCB6B))
        paint(Regex("\"(?:[^\"\\\\\\n]|\\\\.)*\""), Color(0xFFC3E88D))
        paint(Regex("#.*|<!--.*?-->"), Color(0xFF6B7394))
        return TransformedText(a.toAnnotatedString(), OffsetMapping.Identity)
    }
}

@Composable
fun EditorScreen(vm: DexVM, f: File) {
    val ctx = LocalContext.current
    val isImg = f.extension.lowercase() in setOf("png", "jpg", "jpeg", "webp")
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(12.dp)) {
        Text(f.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 6.dp))
        if (isImg) {
            var ver by remember { mutableIntStateOf(0) }
            val bmp = remember(f, ver) { BitmapFactory.decodeFile(f.path)?.asImageBitmap() }
            val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
                if (u != null) {
                    ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    ver++
                }
            }
            bmp?.let { Image(it, null, Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Fit) }
            Button(onClick = { pick.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.replace_image)) }
        } else {
            var text by remember(f) { mutableStateOf(if (f.length() > 1_000_000 || !Engine.isText(f)) null else f.readText()) }
            val savedMsg = stringResource(R.string.saved)
            if (text == null) {
                Text(stringResource(R.string.binary_file), color = Color.Gray)
            } else {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    OutlinedTextField(
                        value = text!!, onValueChange = { text = it },
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color(0xFFE6E9FF)),
                        visualTransformation = Highlight(),
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    )
                }
                Button(
                    onClick = { f.writeText(text!!); vm.status = savedMsg },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                ) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.save)) }
            }
        }
        StatusBar(vm)
    }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
        Text(stringResource(R.string.settings), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.language), modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("ar")) }) { Text(stringResource(R.string.lang_ar)) }
            Button(onClick = { AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("en")) }) { Text(stringResource(R.string.lang_en)) }
        }
        Text(stringResource(R.string.about), color = Color(0xFFB8C0E0), fontSize = 13.sp, modifier = Modifier.padding(top = 24.dp))
    }
}

fun install(ctx: Context, f: File) {
    val uri: Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    ctx.startActivity(
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}
