package com.waleed.dexlab

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class DexVM(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>().applicationContext

    var project by mutableStateOf<File?>(null)
    var cwd by mutableStateOf<File?>(null)
    var status by mutableStateOf("")
    var busy by mutableStateOf(false)
    var apps by mutableStateOf<List<AppItem>>(emptyList())
    var hits by mutableStateOf<List<Hit>>(emptyList())
    var signed by mutableStateOf<File?>(null)

    private fun s(id: Int, vararg a: Any): String = ctx.getString(id, *a)

    private fun work(block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) { block() }
            } catch (t: Throwable) {
                status = "✗ " + (t.message ?: t.javaClass.simpleName)
            } finally {
                busy = false
            }
        }
    }

    fun loadApps() {
        if (apps.isNotEmpty()) return
        work { apps = Engine.installedApps(ctx) }
    }

    private fun load(tmp: File) {
        val pi = ctx.packageManager.getPackageArchiveInfo(tmp.path, 0)
        val name = pi?.packageName ?: "apk_" + (System.currentTimeMillis() % 10000)
        val d = Engine.unpack(ctx, tmp, name)
        signed = null
        hits = emptyList()
        cwd = d
        project = d
        status = s(R.string.ready, name)
    }

    fun openUri(u: Uri) = work {
        status = s(R.string.unpacking)
        val tmp = File(ctx.cacheDir, "in.apk")
        ctx.contentResolver.openInputStream(u)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        load(tmp)
    }

    fun openInstalled(a: AppItem) = work {
        status = s(R.string.unpacking)
        val tmp = File(ctx.cacheDir, "in.apk")
        File(a.path).copyTo(tmp, overwrite = true)
        load(tmp)
    }

    fun decompile() = work {
        val d = project ?: return@work
        status = s(R.string.decompiling)
        Engine.decompile(d)
        status = s(R.string.decompiled)
    }

    fun build() = work {
        val d = project ?: return@work
        status = s(R.string.building)
        val f = Engine.build(ctx, d)
        signed = f
        status = s(R.string.signed_ok, "%.1f MB".format(f.length() / 1048576.0))
    }

    fun search(q: String) = work { hits = Engine.search(project ?: return@work, q) }

    fun export(u: Uri) = work {
        val f = signed ?: return@work
        ctx.contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        status = s(R.string.exported)
    }

    fun close() { project = null; cwd = null; signed = null; hits = emptyList(); status = "" }
}
