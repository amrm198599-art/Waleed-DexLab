# Waleed DexLab

Android app (Kotlin + Jetpack Compose, Arabic / English) to unpack, decompile (smali), edit, rebuild and sign APKs directly on the phone.

## Get the APK from GitHub
1. Push this repo to GitHub (branch `main`).
2. Open **Actions → Build APK**, wait for the green check.
3. Download the artifact **WaleedDexLab-debug** (contains `app-debug.apk`).
4. For a public download: create a tag such as `v1.0` → the APK is attached to the Release automatically.

## Build locally
Open in Android Studio (Koala or newer) and press Run, or: `gradle assembleDebug` (Gradle 8.7, JDK 17).

## Core code
- `app/src/main/java/com/waleed/dexlab/Engine.kt` — unzip, DEX→smali, smali→DEX, zip + align, APK signing, search
- `DexVM.kt` — state / background work
- `MainActivity.kt` — Compose UI

For educational use on apps you own or have permission to modify.
