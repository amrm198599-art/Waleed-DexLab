package com.waleed.dexlab

import android.content.Context
import android.os.Environment
import com.android.apksig.ApkSigner
import org.jf.baksmali.Baksmali
import org.jf.baksmali.BaksmaliOptions
import org.jf.dexlib2.DexFileFactory
import org.jf.dexlib2.Opcodes
import org.jf.smali.Smali
import org.jf.smali.SmaliOptions
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.OutputStream
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class AppItem(val label: String, val pkg: String, val path: String)
data class PkgFile(val name: String, val file: File)
data class Opened(val dir: File, val kind: String, val splits: Int = 0)
data class Hit(val rel: String, val line: Int, val text: String, val file: File)

object Engine {
    private const val KS_PASS = "dexlab123"

    fun workRoot(ctx: Context) = File(ctx.filesDir, "work").apply { mkdirs() }

    fun installedApps(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0)
            .map { AppItem(pm.getApplicationLabel(it).toString(), it.packageName, it.sourceDir) }
            .sortedBy { it.label.lowercase() }
    }

    /** Unzips the APK into <project>/files and keeps a copy as original.apk */
    fun unpack(ctx: Context, apk: File, name: String, orig: String = "original.apk"): File {
        val dir = File(workRoot(ctx), name.take(60))
        dir.deleteRecursively()
        val files = File(dir, "files").apply { mkdirs() }
        val base = files.canonicalPath + File.separator
        ZipFile(apk).use { zip ->
            for (e in zip.entries()) {
                val out = File(files, e.name)
                if (!out.canonicalPath.startsWith(base)) continue // zip-slip guard
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    zip.getInputStream(e).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                }
            }
        }
        apk.copyTo(File(dir, orig), overwrite = true)
        return dir
    }

    /** classes*.dex (APK root, or <module>/dex/ inside an AAB) -> smali/<name>/ */
    fun decompile(dir: File) {
        val files = File(dir, "files")
        val rx = Regex("classes\\d*\\.dex")
        val dexes = files.walkTopDown()
            .filter { it.isFile && rx.matches(it.name) && (it.parentFile == files || it.parentFile?.name == "dex") }
            .sortedBy { it.path }.toList()
        for (dex in dexes) {
            val rel = dex.relativeTo(files).path.removeSuffix(".dex").replace(File.separatorChar, '_')
            val out = File(dir, "smali/$rel")
            out.deleteRecursively(); out.mkdirs()
            val df = DexFileFactory.loadDexFile(dex, Opcodes.getDefault())
            val jobs = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
            Baksmali.disassembleDexFile(df, out, jobs, BaksmaliOptions())
        }
    }

    /** DEX -> readable Java + decoded resources/manifest using jadx (called by reflection so a failure never breaks the app) */
    fun decompileJava(dir: File) {
        val apk = File(dir, "original.apk")
        require(apk.exists()) { "Java decompile needs an APK" }
        val out = File(dir, "java")
        out.deleteRecursively(); out.mkdirs()
        try {
            val ac = Class.forName("jadx.api.JadxArgs")
            val args = ac.getDeclaredConstructor().newInstance()
            try {
                ac.getMethod("setInputFile", File::class.java).invoke(args, apk)
            } catch (e: NoSuchMethodException) {
                ac.getMethod("setInputFiles", List::class.java).invoke(args, listOf(apk))
            }
            ac.getMethod("setOutDir", File::class.java).invoke(args, out)
            ac.getMethod("setThreadsCount", Int::class.javaPrimitiveType).invoke(args, 2)
            ac.getMethod("setShowInconsistentCode", Boolean::class.javaPrimitiveType).invoke(args, true)
            val dc = Class.forName("jadx.api.JadxDecompiler")
            val dec = dc.getConstructor(ac).newInstance(args)
            try {
                dc.getMethod("load").invoke(dec)
                dc.getMethod("save").invoke(dec)
            } finally {
                (dec as java.io.Closeable).close()
            }
        } catch (e: java.lang.reflect.InvocationTargetException) {
            throw RuntimeException(e.targetException.toString(), e.targetException)
        }
        val src = File(out, "sources")
        if (!src.exists() || src.list().isNullOrEmpty()) error("jadx produced no sources")
    }

    fun zipDir(src: File, out: OutputStream) {
        ZipOutputStream(BufferedOutputStream(out)).use { z ->
            src.walkTopDown().filter { it.isFile }.forEach { f ->
                z.putNextEntry(ZipEntry(f.relativeTo(src).invariantSeparatorsPath))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
    }

    /** Opens .apk, .aab, or split bundles (.apks / .xapk / .apkm) */
    fun open(ctx: Context, src: File, display: String): Opened {
        val safe = display.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "app" }
        ZipFile(src).use { z ->
            val names = z.entries().asSequence().filter { !it.isDirectory }.map { it.name }.toList()
            if ("base/manifest/AndroidManifest.xml" in names) {
                return Opened(unpack(ctx, src, safe, "original.aab"), "AAB")
            }
            if ("AndroidManifest.xml" !in names) {
                val apks = names.filter { it.endsWith(".apk", ignoreCase = true) }
                if (apks.isNotEmpty()) {
                    val pick = apks.firstOrNull { it.substringAfterLast('/').startsWith("base", ignoreCase = true) }
                        ?: apks.maxByOrNull { z.getEntry(it).size }!!
                    val inner = File(ctx.cacheDir, "base.apk")
                    z.getInputStream(z.getEntry(pick)).use { i -> inner.outputStream().use { o -> i.copyTo(o) } }
                    val pkg = ctx.packageManager.getPackageArchiveInfo(inner.path, 0)?.packageName ?: safe
                    return Opened(unpack(ctx, inner, pkg), "SPLIT", apks.size)
                }
            }
        }
        val pkg = ctx.packageManager.getPackageArchiveInfo(src.path, 0)?.packageName ?: safe
        return Opened(unpack(ctx, src, pkg), "APK")
    }

    /** Finds .apk files on shared storage (Downloads included) */
    fun scan(root: File = Environment.getExternalStorageDirectory(), max: Int = 600): List<PkgFile> {
        val ext = setOf("apk") // only APK files
        return root.walkTopDown()
            .onEnter { d -> !d.name.startsWith(".") && !(d.parentFile?.name == "Android" && (d.name == "data" || d.name == "obb")) }
            .filter { it.isFile && it.extension.lowercase() in ext }
            .take(max).toList()
            .sortedByDescending { it.lastModified() }
            .map { PkgFile(it.name, it) }
    }

    /** smali -> dex, zip everything, align resources.arsc, sign. Returns signed.apk */
    fun build(ctx: Context, dir: File): File {
        val stage = File(dir, "stage").apply { deleteRecursively(); mkdirs() }
        File(dir, "smali").listFiles()?.filter { it.isDirectory }?.forEach { d ->
            val opts = SmaliOptions().apply {
                outputDexFile = File(stage, d.name + ".dex").path
                apiLevel = 26
            }
            if (!Smali.assemble(opts, listOf(d.path))) error("Smali error in ${d.name}")
        }
        val unsigned = File(dir, "unsigned.apk")
        writeZip(File(dir, "files"), stage, unsigned)
        val signed = File(dir, "signed.apk")
        sign(ctx, unsigned, signed)
        stage.deleteRecursively()
        return signed
    }

    private class Counting(o: OutputStream) : FilterOutputStream(o) {
        var n = 0L
        override fun write(b: Int) { out.write(b); n++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); n += len }
    }

    private fun writeZip(root: File, stage: File, out: File) {
        val sig = Regex("META-INF/.*(\\.SF|\\.RSA|\\.DSA|\\.EC|MANIFEST\\.MF)$")
        val entries = LinkedHashMap<String, File>()
        root.walkTopDown().filter { it.isFile }.forEach { f ->
            val n = f.relativeTo(root).invariantSeparatorsPath
            if (!sig.matches(n)) entries[n] = f
        }
        stage.listFiles()?.forEach { entries[it.name] = it } // rebuilt dex files replace originals
        val c = Counting(BufferedOutputStream(FileOutputStream(out)))
        ZipOutputStream(c).use { z ->
            for ((name, f) in entries) {
                val e = ZipEntry(name)
                if (name == "resources.arsc") {
                    // must be STORED and 4-byte aligned for Android 11+
                    val data = f.readBytes()
                    e.method = ZipEntry.STORED
                    e.size = data.size.toLong(); e.compressedSize = e.size
                    e.crc = CRC32().apply { update(data) }.value
                    val base = c.n + 30 + name.toByteArray().size
                    val pad = ((4 - (base % 4)) % 4).toInt()
                    if (pad != 0) {
                        val len = pad + 4
                        val x = ByteArray(len)
                        x[0] = 0x35; x[1] = 0xD9.toByte(); x[2] = (len - 4).toByte()
                        e.extra = x
                    }
                    z.putNextEntry(e); z.write(data); z.closeEntry()
                } else {
                    z.putNextEntry(e)
                    f.inputStream().use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
        }
    }

    private fun sign(ctx: Context, input: File, output: File) {
        val ks = KeyStore.getInstance("PKCS12")
        ctx.assets.open("dexlab.p12").use { ks.load(it, KS_PASS.toCharArray()) }
        val key = ks.getKey("dexlab", KS_PASS.toCharArray()) as PrivateKey
        val chain = ks.getCertificateChain("dexlab").map { it as X509Certificate }
        val cfg = ApkSigner.SignerConfig.Builder("dexlab", key, chain).build()
        output.delete()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(input).setOutputApk(output)
            .setV1SigningEnabled(true).setV2SigningEnabled(true).setV3SigningEnabled(true)
            .setMinSdkVersion(26)
            .build().sign()
    }

    fun isText(f: File): Boolean {
        if (f.length() == 0L) return true
        f.inputStream().use {
            val b = ByteArray(512)
            val n = it.read(b)
            for (k in 0 until n) if (b[k] == 0.toByte()) return false
        }
        return true
    }

    fun search(root: File, q: String, max: Int = 300): List<Hit> {
        val res = ArrayList<Hit>()
        if (q.isBlank()) return res
        for (f in root.walkTopDown()) {
            if (res.size >= max) break
            if (!f.isFile || f.length() > 2_000_000 || f.name.endsWith(".apk") || !isText(f)) continue
            var i = 0
            f.useLines { lines ->
                for (l in lines) {
                    i++
                    if (l.contains(q, ignoreCase = true)) {
                        res.add(Hit(f.relativeTo(root).path, i, l.trim().take(160), f))
                        if (res.size >= max) break
                    }
                }
            }
        }
        return res
    }
}
